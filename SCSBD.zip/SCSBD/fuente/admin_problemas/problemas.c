/****************************************************************************
 * Programa adminProblemas.c: Programa encargador de ejecutar el módulo de  *
 administración de problemas. En el cual se mostrará al usuario, todas las  *
 temáticas que incluye este sistema. Dando opción de elegir el tema en el   *
 que se quiere trabajar.
 ***************************************************************************/
#include "adminProblemas.h"

void menu(void){
    
    int opcion;
    
    system("clear");
    printf("\n\tELIGE UN TEMA\n\n");
    printf("1. Problemas de USUARIOS.\n");
    printf("2. Problemas de ALMACENAMIENTO.\n");
    printf("3. Problemas de RED.\n");
    printf("4. Problemas de SERVIDOR.\n");
    printf("5. SALIR\n");
    scanf("%d", &opcion);
    
    switch (opcion) {
        case 1:
            problemas_usuarios();
            break;
        case 2:
            problemas_almacenamiento();
            break;
        case 3:
            problemas_red();
            break;
        case 4:
            problemas_servidor();
            break;
        case 5:
            printf("Adios\n");
            break;
            
        default:
            printf("Opcion invalida\n");
            break;
    }
}

void problemas_usuarios(){
    
    FILE *bitacora_problemas;
    
    if((bitacora_problemas = fopen(PATH_PROBLEMAS_USUARIOS, "rb")) == NULL){
        
        printf("Error al abrir el archivo ");
        exit(1);
    }
    
    else{
        
        system("clear");
        printf("El usuario eligió problemas USUARIOS\n");
        
        while(fread(&problema, sizeof (problema), 1, bitacora_problemas) == 1){
            //fread(&problema, sizeof(problema), 1, problemas);
            printf("id: %d\n", problema.idProblema);
            printf("Descripcion: %s\n", problema.descripcion);
            
        }
    }
    fclose(bitacora_problemas);
}

void problemas_almacenamiento(){
    
    FILE *bitacora_problemas;
    
    if((bitacora_problemas = fopen(PATH_PROBLEMAS_ALMACENAMIENTO, "rb")) == NULL){
        
        printf("Error al abrir el archivo ");
        exit(1);
    }
    
    else{
        
        system("clear");
        printf("El usuario eligió problemas ALMACENAMIENTO\n");
        
        while(fread(&problema, sizeof (problema), 1, bitacora_problemas) == 1){
            printf("id: %d\n", problema.idProblema);
            printf("Descripcion: %s\n", problema.descripcion);
            
        }
    }
    fclose(bitacora_problemas);
}

void problemas_red(){
    
    FILE *bitacora_problemas;
    
    if((bitacora_problemas = fopen(PATH_PROBLEMAS_RED, "rb")) == NULL){
        
        printf("Error al abrir el archivo ");
        exit(1);
    }
    
    else{
        
        system("clear");
        printf("El usuario eligió problemas RED\n");
        
        while(fread(&problema, sizeof (problema), 1, bitacora_problemas) == 1){
            printf("id: %d\n", problema.idProblema);
            printf("Descripcion: %s\n", problema.descripcion);
            
        }
    }
    fclose(bitacora_problemas);
}

void problemas_servidor(){
    
    FILE *bitacora_problemas;
    
    if((bitacora_problemas = fopen(PATH_PROBLEMAS_SERVIDOR, "rb")) == NULL){
        
        printf("Error al abrir el archivo ");
        exit(1);
    }
    
    else{
        
        system("clear");
        printf("El usuario eligió problemas SERVIDOR\n");
        
        while(fread(&problema, sizeof (problema), 1, bitacora_problemas) == 1){
            printf("id: %d\n", problema.idProblema);
            printf("Descripcion: %s\n", problema.descripcion);
            
        }
    }
    fclose(bitacora_problemas);
}
