/****************************************************************************
 * Programa stub: Programa que se encarga de probar el modulo de gestion de *
 los problemas. Mostrando un menú al usuario sobre la temática que quiere   *
tratar                                                                      *
 ***************************************************************************/

#include "adminProblemas.h"

int main(void){
    
    menu();
}
