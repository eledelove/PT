#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PATH "../util/problemas_servidor.txt"

struct descripcion{
    int idProblema;
    char descripcion[300];
}problema;

int main(){
    
    FILE *file;
    char descrip[300] = "Este es el SEGUNDO problema de SERVIDOR, el objetivo es resolverlo y trata de esto ....... consigue resolverlo rapido";
    
    if((file = fopen(PATH, "ab+")) == NULL){
        printf("Error al abrir el archivo");
        exit(1);
    }
    else{
        problema.idProblema = 2;
        strcpy(problema.descripcion, descrip);
        
        fwrite(&problema, sizeof(problema), 1, file);
        fclose(file);
    }
    
    return 0;
}
