/*Headers requeridos*/
#include <stdio.h>
#include <stdlib.h>

/*Definicion de macros*/
#define LONGITUD_DESCRIPCION 300

#define PATH_PROBLEMAS_USUARIOS "../fuente/util/problemas_usuarios.txt"
#define PATH_PROBLEMAS_ALMACENAMIENTO "../fuente/util/problemas_almacenamiento.txt"
#define PATH_PROBLEMAS_RED "../fuente/util/problemas_red.txt"
#define PATH_PROBLEMAS_SERVIDOR "../fuente/util/problemas_servidor.txt"

/*Definicion de estructuras*/
struct descripcion{
    int idProblema;
    char descripcion[LONGITUD_DESCRIPCION];
}problema;

/*Prototipo de las funciones*/
void menu(void);
void problemas_usuarios();
void problemas_almacenamiento();
void problemas_red();
void problemas_servidor();
