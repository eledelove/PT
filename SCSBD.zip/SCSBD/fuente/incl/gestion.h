/*Headers requeridos*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Definicion de macros*/
#define LONGITUD_ARREGLO 11

/*Prototipo de las funciones*/
void menu(void);
void login(void);
void registro(void);
