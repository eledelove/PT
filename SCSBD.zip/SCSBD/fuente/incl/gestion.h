/*Headers requeridos*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Definicion de macros*/
#define LONGITUD_NOMBRE 12
#define LONGITUD_PIN 6

#define PATH_USERS "../fuente/util/users.txt"

/*Definicion de estructuras*/
struct datos{
    char name[LONGITUD_NOMBRE];
    char password[LONGITUD_PIN];
    int problemas_resueltos;
}usuario;

/*Prototipo de las funciones*/
void menu(void);
void login(void);
void registro(void);
