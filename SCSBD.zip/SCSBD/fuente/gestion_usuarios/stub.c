/****************************************************************************
 * Programa stub: Aplicacion para la Capacitacion en Soluciones de Problemas*
 para la Administracion de un servidor de Base de Datos.
 ***************************************************************************/

#include "gestion.h"

int main(void){
    
    menu();
}
