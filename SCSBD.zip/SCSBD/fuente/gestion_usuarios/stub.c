/****************************************************************************
 * Programa stub: Programa que se encarga de probar el modulo de gestion de *
 los usuarios, mostrando un menú donde las opciones disponibles son:        *
                                                                            *
 1. Login                                                                   *
 2. Registro                                                                *
 3. Salir                                                                   *
 ***************************************************************************/

#include "gestion.h"

int main(void){
    
    menu();
}
