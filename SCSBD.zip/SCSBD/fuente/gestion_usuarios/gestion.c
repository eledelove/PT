/****************************************************************************
 * Programa gestion.c: Programa encargado de ejecutar las funciones del     *
 módulo gestión de usuarios. Funciones implementadas, login(), resgistro()  *
 y menú().                                                                  *
 ***************************************************************************/

#include "gestion.h"

/*Funcion que verifica si el usuario ya ha está regitrado y da acceso a la aplicacion*/
void login(void){
    
    FILE *bitacora;
    char auxName[LONGITUD_NOMBRE];
    char auxPassword[LONGITUD_PIN];
    int inicioSesion = 0;
    int letrero = 0;
    
    if((bitacora = fopen(PATH_USERS, "rb")) == NULL){
        
        printf("Error al abrir la bitacora de usuarios");
        exit(1);
    }
    else{
        
        system("clear");
        do{
            
            fseek(bitacora, 0, SEEK_SET);
            printf("\n\nuser: ");
            scanf("%s", auxName);
            getchar();

            pidePassword(auxPassword);
	    strcpy(usuario.password, auxPassword);       
            
            while (!feof(bitacora)) {
                fread(&usuario, sizeof(usuario), 1, bitacora);
                if (strstr(auxName, usuario.name) != NULL) {
                    if(strcmp(auxPassword, usuario.password) == 0){
                        inicioSesion = 1;
                        letrero = 0;
                        break;
                    }
                    else letrero = 1;
                }
                else letrero = 1;
            }
            
            if(letrero == 1){
                printf("Error al Iniciar Sesion, intente de nuevo");
            }
            
        }while(inicioSesion == 0);
        
        printf("Bienvenido: %s\n", usuario.name);
        printf("Problemas Resueltos: %d\n", usuario.problemas_resueltos);
        fclose(bitacora);
        
    }
}

/*Fucion que da de alta a los nuevos usuarios para el uso de la Aplicacion*/
void registro(void){
    
    FILE *bitacora;
    char auxPassword[LONGITUD_PIN];

    if((bitacora = fopen(PATH_USERS, "ab+")) == NULL){
        
        printf("Error al abrir la bitacora de usuarios");
        exit(1);
    }
    else{
        
        system("clear");
        printf("\n\tREGISTRO\n");
        printf("\nUsuario SIN ESPACIOS (Max 10 caracteres):");
        scanf("%s", usuario.name);
        getchar();
        
	pidePassword(auxPassword);
	strcpy(usuario.password, auxPassword);       
 
        usuario.problemas_resueltos = 0;
        fwrite(&usuario, sizeof(usuario), 1, bitacora);
        printf("Registro Exitoso");
        fclose(bitacora);
        login();
        
    }
    
}

/*funcion que inicia Curses para escribir la contraseña in echo*/
void pidePassword(char password[]){
    
    initscr();
    printw("\nPIN (4 Digitos): ");
    noecho();
    getnstr(password, sizeof(password));
    echo();
    clear();
    endwin();
}

/*Funcion que muestra un menú con las opciones disponibles*/
void menu(void){
    
    int option;
    
    system("clear");
    printf("\n\tINICIO DE SESION\n");
    printf("1. login\n");
    printf("2. Register\n");
    printf("3. Exit\n\n");
    scanf("%d", &option);
    
    switch (option){
        case 1 :
            login();
            break;
            
        case 2 :
            registro();
            break;
            
        case 3 :
            printf( "Adios\n" );
            break;
            
        default : printf( "ERROR: Opcion incorrecta." );
    }
}
