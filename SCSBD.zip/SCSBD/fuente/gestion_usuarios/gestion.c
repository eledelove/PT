/****************************************************************************
 * Programa gestion.c: prorama que gestiona a los usuarios que usan la Appl-*
 cacion SCSBD.
 ***************************************************************************/

#include "gestion.h"

struct datos{
    char name[11];
    char password[11];
}usuario;

/*Funcion que verifica si el usuario ya ha está regitrado y da acceso a la aplicacion*/
void login(void){
    
    FILE *bitacora;
    char auxName[11];
    char auxPassword[11];
    int inicioSesion = 0;
    int letrero = 0;
    
    if((bitacora = fopen("users.txt", "rb")) == NULL){
        
        printf("Error al abrir la bitacora de usuarios");
        exit(1);
    }
    else{
        
        system("clear");
        do{
            
            fseek(bitacora, 0, SEEK_SET);
            printf("\nuser: ");
            scanf("%s", auxName);
            getchar();
            
            printf("password: ");
            scanf("%s", auxPassword);
            getchar();
            
            while (!feof(bitacora)) {
                fread(&usuario, sizeof(usuario), 1, bitacora);
                if (strstr(auxName, usuario.name) != NULL) {
                    if(strcmp(auxPassword, usuario.password) == 0){
                        inicioSesion = 1;
                        letrero = 0;
                        break;
                    }
                }
                else letrero = 1;
            }
            
            if(letrero == 1){
                printf("Error al Iniciar Sesion");
            }
            
        }while(inicioSesion == 0);
        
        printf("Bienvenido: %s\n", usuario.name);
        fclose(bitacora);
        
    }
}

/*Fucion que da de alta a los nuevos usuarios para el uso de la Aplicacion*/
void registro(void){
    
    FILE *bitacora;
    
    if((bitacora = fopen("users.txt", "ab+")) == NULL){
        
        printf("Error al abrir la bitacora de usuarios");
        exit(1);
    }
    else{
        
        system("clear");
        printf("\nIntroduce un usuario: ");
        scanf("%s", usuario.name);
        getchar();
        
        printf("Introduce un password: ");
        scanf("%s", usuario.password);
        getchar();
        
        fwrite(&usuario, sizeof(usuario), 1, bitacora);
        printf("Registro Exitoso");
        fclose(bitacora);
        login();
        
    }
    
}

/*Funcion que muestra un menú con las opciones disponibles*/
void menu(void){
    
    int option;
    
    system("clear");
    printf("\n\tINICIO DE SESION\n");
    printf("1. login\n");
    printf("2. Register\n");
    printf("3. Exit\n\n");
    scanf("%d", &option);
    
    switch (option){
        case 1 :
            login();
            break;
            
        case 2 :
            registro();
            break;
            
        case 3 :
            printf( "Adios\n" );
            break;
            
        default : printf( "ERROR: Opcion incorrecta." );
    }
}
