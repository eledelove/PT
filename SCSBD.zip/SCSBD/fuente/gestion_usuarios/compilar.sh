#!/bin/sh
#Script para compilar le módulo gestion de usuarios
ACTUAL=$PWD
cd ../../bin
BIN=$PWD
cd $ACTUAL
cd ../../lib
LIB=$PWD/
cd $ACTUAL
cd ../incl
INCL=$PWD/
cd $ACTUAL
make $* RUTA_BIN=$BIN/ RUTA_LIB=$LIB/ RUTA_INCL=$INCL/
